﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _18CSharpStaticUtilityClasses
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Area of rectangle: {0}", ShapeMath.GetArea("Rectangle", 50.0, 10.0));
            Console.ReadLine();

        }
    }
}
