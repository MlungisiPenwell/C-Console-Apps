﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _14CSharpDerekBanasMethods
{
    class Program
    {
        static void Main(string[] args)
        {
            //x and y are not going to change by value
            double x = 5;
            double y = 4;

            Console.WriteLine("5 + 4 = {0}", GetSum(x, y));

            Console.WriteLine("x {0}", x);
            Console.WriteLine("y {0}", y);

            int solution;
            DoubleIt(15, out solution);
            Console.WriteLine("15 * 2 = {0}", solution);

            //By Reference
            int num1 = 10;
            int num2 = 20;
            Console.WriteLine("Before Swap num1 : {0}" +
                " num2 : {1}", num1, num2);
            Swap(ref num1, ref num2);
            Console.WriteLine("After Swap num1 : {0}" +
                " num2 : {1}", num1, num2);

            //Using params you can pass any number of parameters like in java we use ..
            Console.WriteLine("1 + 2 + 3 = {0}",
                GetSumMore(1, 2, 3));

            // lets say  i want to pass zipcode before name: we use named parameters
            PrintInfo(zipCode: 15147, name: "Mlungisi Khumalo");

            //Method overload GetSum
            Console.WriteLine("5 + 4 = {0}", GetSum(5.0, 4.5));
            //Pass String to GetSum overloaded method
            Console.WriteLine("5 + 4 = {0}", GetSum("5", "4,5"));
            Console.ReadLine();
        }

        //Pass By Value
        static double GetSum(double x = 1, double y = 1)
        {
            double temp = x;
            x = y;
            y = temp;

            return x + y;
        }

        //Overload
        static double GetSum(string x = "1", string y = "1")
        {

            double dblX = Convert.ToDouble(x);
            double dblY = Convert.ToDouble(y);
            

            return dblX + dblY;
        }


        //Working and affecting the value outside the methosd using out keyword
        static void DoubleIt(int x , out int solution)
        {
            solution = x * 2; //manipulate a value outside method
        }
        //Pass By Reference 2
        static void Swap(ref int num1 , ref int num2 )
        {
            int temp = num1;
            num1 = num2;
     
        }

        static double GetSumMore(params double[] nums)
        {
            double sum = 0;

            foreach (var i in nums)
            {
                sum += i;
            }
            return sum;
        }

        static void PrintInfo(string name, int zipCode)
        {
            Console.WriteLine("{0} live in the zip code {1}", name, zipCode);
        }
    }
}
