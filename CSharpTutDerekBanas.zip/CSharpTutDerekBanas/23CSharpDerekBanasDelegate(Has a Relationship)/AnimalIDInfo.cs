﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _23CSharpDerekBanasDelegate_Has_a_Relationship_
{
    class AnimalIDInfo
    {
        //Aggregate is an object stored in other object
        public int IDNum { get; set; } = 0;

        public string Owner { get; set; } = "No Owner";
        
    }

}
