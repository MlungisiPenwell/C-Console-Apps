﻿using System;


namespace _17CSharpDerekBanasClassOOP
{
    class Animal
    {
        private string name;
        private string sound;
        private static int numberOfAnimals=0;

        public Animal()
        {
            name = "No name";
            sound = "No sound";
            numberOfAnimals++;
        }

        public Animal(string name = "No name")
        {
            this.name = "No name";
            sound = "No sound";
            numberOfAnimals++;
        }


        public Animal(string name = "No name", string sound="No sound")
        {
            this.name = name;
            this.sound = sound;
            numberOfAnimals++;
        }

        public static int GetNumberOfAnimals()
        {
            return numberOfAnimals;
        }

        public void makeSound()
        {

            Console.WriteLine("{0} says {1}", name, sound);
        }
       
    }
}
