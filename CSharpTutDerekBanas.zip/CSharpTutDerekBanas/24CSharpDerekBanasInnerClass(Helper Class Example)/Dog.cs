﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _24CSharpDerekBanasInnerClass_Helper_Class_Example_
{
    class Dog : Animal
    {
        public string Sound2 { get; set; }
        //to override we use new
        public override void MakeSound() //use this method new Dog();
        {
            Console.WriteLine("{0} says {1} and {2}", Name, Sound, Sound2);
        }

        //constuctor with super class construct using base
        public Dog(string name = "No Name",
            string sound = "No Sound",
            string sound2 = "No Sound")
            : base(name, sound)
        {
            Sound2 = sound2;
        }
    }
}
