﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace  _24CSharpDerekBanasInnerClass_Helper_Class_Example_
{
    class Animal
    {
        private string name;
        protected string sound;

        protected AnimalIDInfo animalIDInfo = new
        AnimalIDInfo();

        public void SetAnimalIDInfo(int IDNum, string owner)
        {
            animalIDInfo.IDNum = IDNum;
            animalIDInfo.Owner = owner;
        }

        public void GetAnimalInfo()
        {
            Console.WriteLine("{0} has the ID of {1} "+
                "and is owned by {2}", Name, animalIDInfo.IDNum, 
                animalIDInfo.Owner);
        }
        public virtual void MakeSound() //Say subclasses can override this method in case of animal = new Dog();
        {
            Console.WriteLine("{0} says {1}", Name, Sound);
        }

        public Animal()
            : this("No Name", "No sound") { }

        public Animal(string name)
            : this(name, "No sound") { }

        public Animal(string name, string sound)
        {
            Name = name;
            Sound = sound;
        }

        public string Name
        {
            get { return name; }
            set
            {
                if (!value.Any(char.IsDigit))
                {
                    this.name = value;
                }
                else
                {
                    name = "No Name";
                    Console.WriteLine("Name can't contain " +
                    "numbers");
                }
            }

        }

        public string Sound
        {
            get { return sound; }
            set
            {
                if (!value.Any(char.IsDigit))
                {
                    this.sound = value;
                }
                else if (value.Length > 10)
                {
                    sound = "No Sound";
                    Console.WriteLine("Sound is too long"
                    );
                }
                else
                {
                    sound = "No Sound";
                    Console.WriteLine("Sound can't contain " +
                         "numbers");
                }
            }

        }

        public class AnimalHealth //helper and can access private member of the surrounding class
        {
        
          public bool HealthyWeight(double height,
              double weight)
          {
             double calc  = height/weight;

              if((calc >= .18) && (calc <= .27))
              {
                 return true;
              }
              else
              {
               return false;
              }
          }

        }
    }





    }
