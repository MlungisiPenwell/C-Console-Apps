﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _16CSharpDerekBanasStruct
{
    class Program
    {
        static void Main(string[] args)
        {
            Rectangle rect1;
            rect1.length = 200;
            rect1.width = 100;

            Console.WriteLine("The area of rect1: {0}", rect1.Area());
            Rectangle rect2 = new Rectangle(100, 40);
            // they pass by value not reference
            rect2 = rect1; // we just get length 200 width 100
            rect1.length = 50; //won't change length from 200 to 50 for rect 2

            Console.WriteLine("Length of rect 2: {0}", rect2.length);
            Console.WriteLine("Width of rect 2: {0}", rect2.width);
            Console.ReadLine();


        }



        struct Rectangle
        {
            public double length;
            public double width;

            public Rectangle(double l = 1, double w = 1)
            {
                length = l;
                width = w;
            }

            public double Area()
            {
                return length * width;
            }

        }

    }
}
