﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _22CSharpDerekBanasInheritanceAndProtectedFields
{
    class Animal
    {
        private string name;
        protected string sound;//can be changed directly by subclass

        public void MakeSound()
        {
            //Console.WriteLine("{0} says {1}", Name, Sound);
            Console.WriteLine($"{Name} says {Sound}"); // using prperties
        }

        public Animal() //calls a constructor that uses 2 parameters to set defaults
            :this("No Name", "No sound"){}

         public Animal(string name)
            :this(name, "No sound"){}

         public Animal(string name, string sound) //this one is called by defalut -nice
         {
             Name =name;
             Sound  = sound;
         }
         
        public string Name
        {
         get { return name;}
         set
            {
              if(!value.Any(char.IsDigit))
              {
                    name = value;
                 
                    
              }else
              {
                    name = "No Name";
                    Console.WriteLine("Name can't contain " +
                    "numbers");
                }
            }
        
        }

        public string Sound
        {
         get { return sound;}
         set
            {
              if(!value.Any(char.IsDigit))
              {
                    sound = value;
                
                }
                else if(value.Length > 10)
              {
               sound = "No Sound";
                  Console.WriteLine("Sound is too long"
                  );
              }else
              {
                    sound = "No Sound";
                    Console.WriteLine("Sound can't contain " +
                         "numbers");
                   
                }
            }
        
        }

       



    }
}
