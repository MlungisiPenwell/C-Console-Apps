﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _22CSharpDerekBanasInheritanceAndProtectedFields
{
    class Program
    {
        static void Main(string[] args)
        {

            Animal whisters = new Animal()
            {
                Name = "Whisters",
                Sound = "Meow"

            };

            Dog grover = new Dog()
            {
                Name = "Grover",
                Sound = "Woof",
                Sound2 = "Grrrr"

            };

           
            grover.sound = "Whooooooof";
            //I can change sound bcz it is protected and name private

            whisters.MakeSound();
            grover.Name = "Groover";
            grover.Sound = "Wooooooof";
            grover.MakeSound();
            Console.ReadLine();

        }
    }
}
