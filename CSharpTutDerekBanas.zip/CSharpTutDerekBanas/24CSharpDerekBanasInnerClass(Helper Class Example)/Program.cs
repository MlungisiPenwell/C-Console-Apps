﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _24CSharpDerekBanasInnerClass_Helper_Class_Example_
{
    class Program
    {
        static void Main(string[] args)
        {
            Animal whisters = new Animal()
            {
                Name = "Whisters",
                Sound = "Meow"

            };

            Dog grover = new Dog()
            {
                Name = "Grover",
                Sound = "Woof",
                Sound2 = "Grrrr"

            };

            whisters.MakeSound();
            //I can change sound bcz it is protected and name private
            grover.Name = "Groover";
            grover.Sound = "Wooooooof";
            grover.MakeSound();

            whisters.SetAnimalIDInfo(1234, "Mlungisi");
            grover.SetAnimalIDInfo(12345, "Bob brown");

            whisters.GetAnimalInfo();
            grover.GetAnimalInfo();

            //calling the inner class
            Animal.AnimalHealth getHealth = new
                Animal.AnimalHealth();

            Console.WriteLine("Is my animal healthy : {0}",
                getHealth.HealthyWeight(11, 146));

            /*
             example of polymorphism
             * when a super class acts as subclass
             * We use virtual on  the Dog method to be overriden
             * And override on the subclass method
             */

            Animal monkey = new Animal()
            {
                Name = "Happy",
                Sound = "Eeeeeee"

            };

            Animal spot = new Dog()
            {
                Name = "Spot",
                Sound = "Wooof",
                Sound2 = "Grrrrrr"

            };

            monkey.MakeSound();
            spot.MakeSound();
            Console.ReadLine();

        }
    }
}
