﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _17CSharpDerekBanasClassOOP
{
    class Program
    {
        static void Main(string[] args)
        {
            Animal fox = new Animal("Rax", "Mbrrrr");
            Animal dog = new Animal("Zazi", "Whoof");
            fox.makeSound();
            dog.makeSound();
            Console.WriteLine("# of animals {0}", Animal.GetNumberOfAnimals());
            Console.ReadLine();

        }
    }
}
