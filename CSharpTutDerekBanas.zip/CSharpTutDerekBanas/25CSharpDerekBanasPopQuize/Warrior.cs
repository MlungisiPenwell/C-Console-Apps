﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _25CSharpDerekBanasPopQuize
{
    class Warrior
    {
        public string Name { get; set; } = "Warrior";

        public double MaxHealth { get; set; } = 0;

        public double MaxAttacks { get; set; } = 0;

        public double MaxBlockValue { get; set; } = 0;

        public Warrior(string name ="Warrior", double maxHealth = 0, double maxAttack = 0, double maxBlock = 0)
        {
            Name = name;
            MaxHealth = maxHealth;
            MaxAttacks = maxAttack;
            MaxBlockValue = maxBlock;

        }
        //TODO 
        //Random numbers
        Random rnd = new Random(); // use single instance and reuse it again and again  if not gonna get same random number

        //Capabilities
        //Attack -Method
        // -Generate a random attack from 1 to maximum attack
        public double Attack()
        {
            return rnd.Next(1, (int)MaxAttacks);
        }

        //Block -Method
        // -Generate a random attack from 1 to maximum block
        public double Block()
        {
            return rnd.Next(1, (int)MaxBlockValue);
        }
    }
}
