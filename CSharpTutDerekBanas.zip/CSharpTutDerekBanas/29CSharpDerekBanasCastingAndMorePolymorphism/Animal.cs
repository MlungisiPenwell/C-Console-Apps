﻿

// ---------- Animal.cs ----------

using System;

namespace _29CSharpDerekBanasCastingAndMorePolymorphism
{
    class Animal
    {
        public  string Name { get; set; }

        public Animal(string name = "No Name")
        {
            Name = name;
        }

        // Anytime you need many overloaded 
        // methods that differ only by their
        // parameters a generic is normally
        // the solution
        public static void GetSum<T>(ref T num1, ref T num2)
        {
            //Get<T> -means we don't know the datatype
            //ref T num1 -- but the returns datatype is going to be the same as num1 and num2 that is what we are saying
            double dblX = Convert.ToDouble(num1);
            double dblY = Convert.ToDouble(num2);
            Console.WriteLine($"{dblX} + {dblY} = {dblX + dblY}");
        }


    }
}
