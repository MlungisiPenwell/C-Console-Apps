﻿// ---------- Animal.cs ----------

namespace _31CSharpDerekBanasOperatorOverLoading
{
    class Animal
    {
        public string Name { get; set; }

        public Animal(string name = "No Name")
        {
            Name = name;
        }
    }
}

// ---------- AnimalFarm.cs ----------