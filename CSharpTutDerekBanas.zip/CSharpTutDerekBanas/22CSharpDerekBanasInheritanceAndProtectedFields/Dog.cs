﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _22CSharpDerekBanasInheritanceAndProtectedFields
{
    // : instead of extend but it inherits properties 
    //And methods of Animal class
    class Dog : Animal //Inheritance is a relationship
    {
        public string Sound2 { get; set; } = "Grrrrr";

       //to override we use new is one way
        public new void MakeSound()
        {
            Console.WriteLine($"{Name} says {Sound} and {Sound2}");
        }

        //constuctor with super class construct using base
        public Dog(string name = "No Name",
            string sound = "No Sound",
            string sound2 = "No Sound")
            : base(name, sound) //super class
        {
            Sound2 = sound2;
          //sound = "ssds"; because it is protected it can be changed by this subclass
        }
    }
}
