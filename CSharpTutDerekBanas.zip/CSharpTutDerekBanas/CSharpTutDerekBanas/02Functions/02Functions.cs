﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutDerekBanas
{
    class _02Functions
    {
        static void Main(string[] args)
        {
            SayHello();
            Console.ReadLine();
        }

        private static void SayHello()
        {
            string name = "";
            Console.Write("What is your name: ");
            name = Console.ReadLine();
            Console.Write("Hello {0}", name);
        }
    }
}
