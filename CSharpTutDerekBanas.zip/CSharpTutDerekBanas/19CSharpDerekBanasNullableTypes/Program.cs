﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Important when we want to work with our database, C# we don't have data types like int which is null
namespace _19CSharpDerekBanasNullableTypes 
{
    class Program
    {
        static void Main(string[] args)
        {

            int? nullNumber = null;

            //two ways to check
            if (nullNumber == null)
            {
                Console.WriteLine("Number is null");
            }

            if (!nullNumber.HasValue)
            {
                Console.WriteLine("Number is null");
            }
            Console.ReadLine();

        }
    }
}
