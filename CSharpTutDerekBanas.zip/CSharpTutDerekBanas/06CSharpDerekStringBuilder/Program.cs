﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
namespace _06CSharpDerekStringBuilder
{
    class Program
    {
        static void Main(string[] args)
        {
            //everytime we make a change in the string it create a brand new string which is ineffecient

            //Solution is the StringBuilder to modify and not create new string

            StringBuilder sb = new StringBuilder("Random Text"); //it assign a 16 characters size if not specified

            StringBuilder sb2 = new StringBuilder("More Stuff is important", 256);

            Console.WriteLine("Capacity :{0}", sb.Capacity);
            Console.WriteLine("Capacity :{0}", sb2.Capacity);

            Console.WriteLine("Length :{0}", sb.Length);

            sb2.AppendLine("\nMore important text");

            //Culture specific formating
            CultureInfo enUS = CultureInfo.CreateSpecificCulture("en-US");

            string bestCust = "Bob Smith";
            sb2.AppendFormat(enUS, "Best Customer : {0}", bestCust);

            Console.WriteLine(sb2.ToString());


            sb2.Replace("text", "characters");
            Console.WriteLine(sb2.ToString());

            sb2.Clear(); //

            //compare'
            sb2.Append("Random Text");
            Console.WriteLine(sb.Equals(sb2));

            //insert
            sb2.Insert(11, " that's great");
            Console.WriteLine(sb2.ToString());

            //remove
            sb2.Remove(11, 7);
            Console.WriteLine(sb2.ToString());
            Console.ReadLine();
        }

        static void printArray(int[] intNums, string message)
        {
            foreach (var k in intNums)
            {
                Console.WriteLine("{0} : {1}", message, k);
            }
            Console.WriteLine();

        }
    }
}
