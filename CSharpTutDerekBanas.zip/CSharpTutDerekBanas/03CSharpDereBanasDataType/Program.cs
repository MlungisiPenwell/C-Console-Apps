﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
namespace _03CSharpDereBanasDataType
{
    class Program
    {
        static void Main(string[] args)
        {
            bool canIVote = true;

            //implicit data type
            var intVal = 1234;
            Console.WriteLine("Implicit data type intVal Type : {0}", intVal.GetType());


            //32 bit
            Console.WriteLine("Biggest int: {0}", int.MaxValue);
            Console.WriteLine("Smallest int: {0}", int.MinValue);

            //64
            //32 bit
            Console.WriteLine("Biggest long: {0}", long.MaxValue);
            Console.WriteLine("Smallest long: {0}", long.MinValue);

            decimal decPiVal = 3.1415926535897932384626433832M;
            decimal decBigNum = 3.00000000000000000000000000011M;
            Console.WriteLine("Biggest decimal: {0}", decimal.MaxValue);
            Console.WriteLine("Smallest decimal {0}",decimal.MinValue);
            Console.WriteLine("DEC : PI + Big Num {0}", decPiVal+decBigNum);

            //doubles smaller than decimal
            double dblPiVal = 3.14159265358979;
            double dblBigNum = 3.000000000000002;
            Console.WriteLine("Biggest double: {0}", double.MaxValue);
            Console.WriteLine("Smallest double {0}", double.MinValue);
            Console.WriteLine("DEC : PI + Big Num {0}", dblPiVal + dblBigNum);

            //32 bit floating value
            float fltPiVal = 3.141592F;
            double fltBigNum = 3.000002;
            Console.WriteLine("Biggest float: {0}", float.MaxValue.ToString("#"));//shows all zero
            Console.WriteLine("Smallest float {0}", float.MinValue);
            Console.WriteLine("FLT : PI + Big Num {0}", fltPiVal + fltBigNum);

            //Converting
            bool boolFromStr = bool.Parse("true");
            int intFromStr = int.Parse("100");
            double dlFromStr = double.Parse("1,234");

            //Casting om second video
            long num1 = 1234;
            int num2 = (int)num1;
            Console.WriteLine("Original : {0} and Cast : {1}", num1.GetType(), num2.GetType());

            //Other DataType 
            //DateTime Date Time
            DateTime awesomeDate = new DateTime(1974, 12, 21);
            Console.WriteLine("Day of the week  {0}", awesomeDate.DayOfWeek);

            //change to add 4 days
            awesomeDate = awesomeDate.AddDays(4);
            awesomeDate = awesomeDate.AddMonths(1);
            awesomeDate = awesomeDate.AddYears(1);
            Console.WriteLine("New Date  {0}", awesomeDate.Date);

            //Time
            TimeSpan launchTime = new TimeSpan(12, 30, 0);
            launchTime = launchTime.Subtract(new TimeSpan(0, 15, 0));
            launchTime = launchTime.Add(new TimeSpan(1, 0, 0));
            Console.WriteLine("New Launch Time  {0}", launchTime.ToString());

            //Big Integers on Visual Studio project>Add References> tick System.Numeric checkbox
            BigInteger bigNum = BigInteger.Parse("12341234123412341234123412341234");
            Console.WriteLine("BigNum * 2 : {0}", bigNum * 2);

            //Formating
            //Currency
            Console.WriteLine("Formatting");
            Console.WriteLine("Currency : {0:c}", 23.455);//R23.4555
            Console.WriteLine("Pad with 0s : {0:d4}", 23);//0023
            Console.WriteLine("3 Decimals : {0:f3}", 23.4555);//23.456
            Console.WriteLine("Commas : {0:n4}", 2300);//2 300 , 0000

            Console.ReadLine();
        }
    }
}
