﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _29CSharpDerekBanasCastingAndMorePolymorphism
{
    class Car<T>
    {
        private T modelName;

        public Car( T modelName)
        {
            ModelName = modelName;
        }
        public T ModelName
        {
            get { return modelName; }
            set { modelName = value; }
        }

        public void GetSound<T> ()
        {
            Console.WriteLine($"{ModelName} start like Vrmmmm!");
        }
    }
}
