﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _25CSharpDerekBanasPopQuize
{
    class Battle //Utility Class bacause it will not use instance
    {

        private static Warrior firstWarrior;

        private static Warrior secondWarrior;

         public static void StartFight(Warrior warrior1, Warrior warrior2)
        {
           firstWarrior = warrior1;
            secondWarrior = warrior2;

            //TODO - Done
            // - Loop giving each warrior a chance to 
            //Attack and Block each turn until 1 dies
            while (true)
            {
                if (GetAttackResult(warrior1, warrior2 )== "Game Over")
                {
                    Console.WriteLine("Game Over");
                    break;
                }
                //Opposite attack
                if (GetAttackResult(warrior2, warrior1) == "Game Over")
                {
                    Console.WriteLine("Game Over");
                    break;
                }
            }

            

            

            
           

           
            /* Output
             Bob Attacks Maximus and Deals 74 Demage
             Maximus Has 69 Health

             Maximus Attacks Bob and Deals 6 Demage
             Bob Has 6 Health

            Bob Attacks Maximus and Deals 48  Demage
             Maximus Has 21 Health

            Bob dies and MAximus is victorious
              */


        }

        //GetAttackResult which recieve
        // WarriorA, WarriorB

        private static string GetAttackResult(Warrior warriorA, Warrior warriorB)
        {
           
            
            double warAAttackAmnt = warriorA.Attack();
            double warBBlockAmnt = warriorB.Block();

            // Calculations 1 attack and others block

            // - Subtract block from attack
            double demageToWarriorB = warAAttackAmnt - warBBlockAmnt;
            //if There was demage substract that from the health
            if (demageToWarriorB > 0)
            {
                //update health
                warriorB.MaxHealth = warriorB.MaxHealth - demageToWarriorB;
            }
            else demageToWarriorB = 0; //avoid negetive demage

            //Print out info on who attacked who
            //for how much demage
            
            Console.WriteLine("{0} attacks {1} and Deals {2} Demage", warriorA.Name,
                warriorB.Name, demageToWarriorB);

            //prove output on the change in health
            Console.WriteLine("{0} Has {1} Health \n", warriorB.Name, warriorB.MaxHealth);

            // Check if the wariiors health fell below 0 and if so print a message and then
            // send a response that will end the loop

            if (warriorB.MaxHealth <= 0)
            {
                Console.WriteLine("{0} has Died and {1} is Victorius \n", warriorB.Name, warriorA.Name);

                return "Game Over";
            }
            return "Fight Again";
        }

    }
}
