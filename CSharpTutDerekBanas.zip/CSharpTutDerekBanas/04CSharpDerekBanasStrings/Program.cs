﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04CSharpDerekBanasStrings
{
    class Program
    {
        static void Main(string[] args)
        {
            //Strings
            Console.WriteLine("Strings Fuctions");
            string randString = "This is a string";
            Console.WriteLine("String Lenght : {0}", randString.Length);

            Console.WriteLine("String contains is : {0}", randString.Contains("is"));

            Console.WriteLine("Index is : {0}", randString.IndexOf("is"));

            Console.WriteLine("Remove String  : {0}", randString.Remove(0, 6));

            Console.WriteLine("Insert String : {0}", randString.Insert(9, "short"));

            Console.WriteLine("Replace String : {0}", randString.Replace("string", "sentence"));

            Console.WriteLine("SubString 10 : {0}", randString.Substring(10));//Substring(int startIndex)

            Console.WriteLine("SubString 0, 6 : {0}", randString.Substring(0, 4));//String.Substring Method (int startIndex, int length)
            Console.WriteLine("Mlungisi + Khumalo : {0}", "Mlungisi"+ " Khumalo");
            // Taking a string 
            // Split(String[], Int32, StringSplitOptions) 
            /*
             public String[] Split(String[] separator, int count, StringSplitOptions options);
Parameters:

separator: It is a string array which delimits the substrings in this string, an empty array that contains no delimiters, or null.
count: It is the maximum number of substring to return.
options: RemoveEmptyEntries option to omit empty array elements from the array returned or None option to include empty array elements in the array returned.
Return: This method returns an array whose elements contain the substrings in this string which are delimited by one or more characters in the separator.

Exceptions:

ArgumentOutOfRangeException: If the count is negative.
ArgumentException: If the options is not one of the StringSplitsOptions 
             */
            String str = "Geeks, For Geeks To Test";

            String[] spearator = { "s, ", "For" };
            Int32 count = 2;
            Console.WriteLine();
            // using the method
            /*
            public String[] Split(char[] separator, int count, StringSplitOptions options);
Parameters:

separator: It is a character array that delimits the substrings in this string, an empty array that contains no delimiters, or null.
count: It is the maximum number of substring to return.
options: RemoveEmptyEntries option to omit empty array elements from the array returned or None option to include empty array elements in the array returned.
Return: It is an array whose elements contain the substrings in this string that are delimited by one or more characters in the separator.

Exceptions:

ArgumentOutOfRangeException: If the count is negative.
ArgumentException: If the options is not one of the StringSplitOptions values.
             */
            String[] strlist = str.Split(spearator, count,
                   StringSplitOptions.RemoveEmptyEntries); //RemoveEmptyEntries will not include , and For separators

            foreach (String s in strlist)
            {
                Console.WriteLine(s);
            }
            Console.WriteLine();
            char[] separator = { 's', ' ' };
            // Using the Method 
            String[] strlist2 = str.Split(separator,
                   count, StringSplitOptions.None); //None will not include 's' separators

            foreach (String s in strlist2)
            {
                Console.WriteLine(s);
            }


            // Taking a string 
            String str2 = "Geeks, For Geeks";

            char[] spearator2 = { ',', ' ' };

            // using the method 
            String[] strlist3 = str2.Split(spearator2,
               StringSplitOptions.RemoveEmptyEntries); //Geeks 
                                                       // For 
                                                       //Geeks
            Console.WriteLine();
            foreach (String s in strlist3)
            {
                Console.WriteLine(s);
            }

            char[] spearator4 = { ',', ' ' };

            // using the method 
            String[] strlist4 = str.Split(spearator4);//Geeks 


            Console.WriteLine();
            // For 
            //Geeks
            foreach (String s in strlist4)
            {
                Console.WriteLine(s);
            }

            //Others
            /*
             // Taking a string 
        String str = "Geeks, For Geeks"; 
  
        char[] spearator = { ',', ' ' }; 
        Int32 count = 2; 
  
        // using the method 
        String[] strlist = str.Split(spearator, count); 
        //output Geeks
                  For Geeks
                  Returns: This method returns an array of strings whose elements contain the substrings 
                  in this string that are delimited by one or more characters in the separator.

Exception: This method will give ArgumentException if the options parameter is not one of the StringSplitOptions values.
                  String[] spearator = { "s,", "For" }; 
  
        // using the method 
        String[] strlist = str.Split(spearator,  
           StringSplitOptions.RemoveEmptyEntries); 
  
        foreach(String s in strlist) 
        { 
            Console.WriteLine(s); 
        } 
    } 
} 
Output:

Geek
 
 Geeks
            String[] spearator = { "s,", "For" }; 
  
        // using the method 
        String[] strlist = str.Split(spearator,  
           StringSplitOptions.RemoveEmptyEntries); 
  
        foreach(String s in strlist) 
        { 
            Console.WriteLine(s); 
        } 
    } 
} 
Output:

Geek
 
Geeks
For More Information https://www.geeksforgeeks.org/string-split-method-in-c-sharp-with-examples/
             */



            Console.WriteLine();
            Console.WriteLine("Compare A  to B : {0}", string.Compare("A", "B", StringComparison.OrdinalIgnoreCase));

            Console.WriteLine("A = a : {0}", String.Equals("A", "a", StringComparison.OrdinalIgnoreCase));

            Console.WriteLine("Pad Left : {0}", randString.PadLeft(20, '.'));

            Console.WriteLine("Pad Right : {0}", randString.PadRight(20, '.'));

            //Trim
            Console.WriteLine("Trim: {0}", randString.Trim());

            Console.WriteLine("UpperCase: {0}", randString.ToUpper());

            Console.WriteLine("LowerCase: {0}", randString.ToLower());

            //formating String
            string newString = String.Format("{0} saw a {1} {2} in the {3}", "Rashida", "rabbit", "eating", "field");
            Console.WriteLine(newString);

            //want to have 
            // \\ \' \"" \"

            // vebatatom string no \"" above
            Console.WriteLine(@"Exactly what I typed ' \ ");

            //from 3rd video comparing strings
            string name = "Derek";
            string name2 = "Derek";
            if (name.Equals(name2, StringComparison.Ordinal))
            {
                Console.WriteLine("{0} equals {1}", name, name2);
            }
            else {
                Console.WriteLine("{0} is not equal {1}", name, name2);
            }
            Console.ReadLine();
        }
    }
}
