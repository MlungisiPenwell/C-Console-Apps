﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _24CSharpDerekBanasInnerClass_Helper_Class_Example_
{
    class AnimalIDInfo
    {
        public int IDNum { get; set; }
        public string Owner { get; set; }
    }
}
