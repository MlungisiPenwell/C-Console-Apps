﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05CSharpDerekBanasArrrays
{
    class Program
    {
        static void Main(string[] args)
        {
            //Arrays

            int[] favNums = new int[3]; // static size
            favNums[0] = 23;

            Console.WriteLine("favNums[0] : ", favNums[0]);

            string[] customers = { "Bob", "Sally", "Sue" };

            //impicit datatype
            var employees = new[] { "Bob", "Sally", "Sue" };

            //mix datetype use object array
            object[] randomArray = { "Bob", 1234, 2.5 };
            Console.WriteLine("randomArray Size  : {0}", randomArray.Length);

            foreach (var s in randomArray)
            {
                Console.WriteLine("randomArray 0 : {0}", s.GetType());
            }

            Console.WriteLine();

            for (int i = 0; i < randomArray.Length; i++)
            {
                Console.WriteLine("randomArray 0 : {0} value : {1}", i, randomArray[i]);
            }

            //Multi Dimensional Array
            string[,] customerNames = new string[2, 2] { { "Bob", "Smith" }, { "Sally", "Marks" } };

            Console.WriteLine("MD value : {0}", customerNames.GetValue(1, 1));

            for (int i = 0; i < customerNames.GetLength(0); i++)
            {
                for (int j = 0; j < customerNames.GetLength(1); j++)
                {
                    Console.Write("{0} ", customerNames[i,j]);
                }
                Console.WriteLine();
            }

            //foreach with method
            int[] randNums = { 1, 4, 9, 2 };
            printArray(randNums, "foreach");

           
            //Sort
            
            Array.Sort(randNums);
            Console.WriteLine("Sorted");
            printArray(randNums, "foreach");

           
            Array.Reverse(randNums);
            Console.WriteLine("Rerved Order");
            printArray(randNums, "foreach");

           
            //get an Inedx and -1 means not found

            Console.WriteLine("1 at Index : {0}", Array.IndexOf(randNums, 1));
            Console.WriteLine();

            //Change value in array
            randNums.SetValue(0, 1);
            printArray(randNums, "foreach");



            //custNames[2,2, 3] // would be matrix of 3 (2 by 2 arrays) 

            //Copy one array to another
            int[] srcArray = { 1, 2, 3 };
            int[] destArray = new int[2];

            int startInd = 0;
            int length= 2;

            Array.Copy(srcArray, startInd, destArray, startInd, length);
            printArray(destArray, "Copy");

            //different way of creating array
            Array anotherArray = Array.CreateInstance(typeof(int), 10);

            srcArray.CopyTo(anotherArray, 5);

            foreach (var m in anotherArray)
            {
                Console.WriteLine("CopyTo : {0}",  m);
                Console.WriteLine();
            }

            //search for element using predicate function
            int[] numArray = {1, 11, 22 };

            Console.WriteLine("> 10  : {0}", Array.Find(numArray, GT10)); 
            // returns 11 because it returns one value(Others is FindAll and FindIndex)
            Console.WriteLine();



            Console.ReadLine( );
        }

        static void printArray(int[] intNums, string message)
        {
            foreach (var k in intNums)
            {
                Console.WriteLine("{0} : {1}", message, k);
            }
            Console.WriteLine();

        }

        private static bool GT10(int val)
        {
            return val > 10;
        }
    }
}
