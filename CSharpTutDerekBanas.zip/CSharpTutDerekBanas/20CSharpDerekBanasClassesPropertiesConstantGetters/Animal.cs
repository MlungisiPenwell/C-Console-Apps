﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _20CSharpDerekBanasClassesPropertiesConstantGetters
{
    class Animal
    {
        //protected means it can be accessed by inside method and subclasses
        //private only changed by method in the class
        private string name;
        private string sound;

        //this constant can not change no matter what
        public const string SHELTER = "Mlungisi home for animals";

        //this constant can be changed at runtime - very cool 
        public readonly int idNum;

        public void MakeSound()
        {

            Console.WriteLine("{0} says {1}", name, sound);
        }

        //complex way of defining a constructor(take the information passed here() passed defaults  up the chain to additional constractor  
        public Animal()
            :this("No Name", "No sound"){}

        public Animal(string name)
            :this(name, "No sound"){} //complaint if no constractor that pass two arguments

        public Animal(string name, string sound)
        { 

            //first way
            SetName(name);
            //property
            Sound = sound;
            NumberOfAnimals = 1;
            Random rnd = new Random();
            //this number is going to be the same for all animals ,so random makes sure we change read-only values
            idNum = rnd.Next(1, 2147483640);
          
        }

        //Setter/ Mutators
        public void SetName(string name)
        {
            if (!name.Any(char.IsDigit)) //check any charactor in name is not a digit
            {
                this.name = name;
            }
            else
            {
                this.name = "No Name";
                Console.WriteLine("Name can not have digits");
            }
        
        }

        //Getter / Accessor
        public string GetName()
        {
            return this.name; //+ "kg"
        }

        //Another way besides setters and getters is to use properties
        public string Sound
        {
            get { return sound; }
            set {

                if (value.Length > 10)
                {
                    sound = "No Sound";
                    Console.WriteLine("Sound is too long");
                }
                else
                {
                    sound = value;
                }
            }
        }

        //C# is able to define by automatically setters and getters but in this case we give our default values
        public string Owner { get; set; } = "No Owner"; // No owner wil be the default value
        //our static value

        public static int numberOfAnimals = 0;

        public static int NumberOfAnimals 
        {
          get{ return numberOfAnimals;}
            set
            {
                //check if it is integer
                string num = value.ToString();
              if(!num.Any(char.IsDigit))
              {
                    Console.WriteLine("Number of Animals only digit(0-9)");
                }
                else
              {
                  
                    numberOfAnimals += value;

                }
            }
        }
             
    }
}
