﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTutDerekBanas
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello Mlungisi");
            //write click the solution and debug 1 2 3 4
            for (int i = 0; i < args.Length; i++)
            {
                Console.WriteLine("Args {0} : {1}", i, args[i]);
            }

            string[] myArgs = Environment.GetCommandLineArgs();

            Console.WriteLine(string.Join(", ", myArgs));
            Console.ReadLine();
        }
    }
}
