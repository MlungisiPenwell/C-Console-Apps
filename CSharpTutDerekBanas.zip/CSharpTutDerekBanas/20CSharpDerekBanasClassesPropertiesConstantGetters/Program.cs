﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20CSharpDerekBanasClassesPropertiesConstantGetters
{
    class Program
    {
        static void Main(string[] args)
        {
            Animal cat = new Animal();
            cat.SetName("Whister");
            cat.Sound = "Meow"; //use property
            Console.WriteLine("The cat is named {0} and says {1}",
                cat.GetName(), cat.Sound); //cat.Sound is property -it is clean

            //working with our auto generated
            cat.Owner = "Mlungisi";
            Console.WriteLine("{0} owner is {1}",
               cat.GetName(), cat.Owner);

            //working with our readonly
            Console.WriteLine("{0} shelter id is {1}",
                cat.GetName(), cat.idNum);

            //our static variable
            Animal fox = new Animal("Oscar", "Rawrr");
            Console.WriteLine("{0} shelter id is {1}",
                fox.GetName(), fox.idNum);
            //idNum is not the same
            Console.WriteLine("# of Animals : {0}", Animal.NumberOfAnimals);
            Console.ReadLine();

        }
    }
}
