﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _13CSharpDerekBanasExceptionHandling
{
    class Program
    {
        static void Main(string[] args)
        {
            double num1 = 5;
            double num2 = 0;

            //C# does not throw an / 0 exception so we need to create our own
            try
            {
                Console.WriteLine("5 / 0  ={0}", DoDivision(num1, num2));
            }
            catch (System.DivideByZeroException ex)
            {
                Console.WriteLine(ex.GetType().Name);
                Console.WriteLine("Error : {0}", ex.Message);
            }
            catch (Exception ex) //any other exception besides DevideByZero
            {
                Console.WriteLine(ex.GetType().Name);
                Console.WriteLine("Error : {0}", ex.Message);
            }
            finally //always gonna run
            {
                Console.WriteLine("Cleaning Up");

            }
                
            
            Console.ReadLine();
        }

        static double DoDivision(double x, double y)
        {
            if (y == 0)
            {
                throw new System.DivideByZeroException();
            }

            return x / y;
        }
    }
}
