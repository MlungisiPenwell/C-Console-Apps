﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12CSharpDerekBanasDoWhileLoopAndRandomNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();
            int secretNumber = rnd.Next(1, 11);
            int numberGuessed = 0;

            do
            {
                Console.Write("Enter a number between 1 and 10 : ");
                //numberGuessed = int.Parse(Console.ReadLine());
                numberGuessed =Convert.ToInt32(Console.ReadLine());

                

            } while (secretNumber != numberGuessed);

            Console.WriteLine("Congratulations!!!!");
                Console.ReadLine(  );
        }
    }
}
