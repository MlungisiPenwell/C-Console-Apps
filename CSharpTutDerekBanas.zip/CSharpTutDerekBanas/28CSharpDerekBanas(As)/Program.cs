﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _28CSharpDerekBanas_As_
{
    class Program
    {
        static void Main(string[] args)
        {
            IElectronicDevice TV = TVRemote.GetDevice();

            PowerButton powButton = new PowerButton(TV);

            powButton.Execute();
            powButton.Undo();
            Console.ReadLine();
        }
    }
}
