﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// ---------- Owner.cs ----------

namespace _32CSharpLINQQurious_Frm_Whr_Odrby_Selct__IEN_InnrGrpJoin
{
    class Owner
    {
        public string Name { get; set; }
        public int OwnerID { get; set; }
    }
}
