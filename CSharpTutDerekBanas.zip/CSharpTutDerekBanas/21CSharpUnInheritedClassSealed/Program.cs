﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _21CSharpUnInheritedClassSealed
{
   sealed class Program // can not have sub class
    {
        static void Main(string[] args)
        {
        }
    }
}
