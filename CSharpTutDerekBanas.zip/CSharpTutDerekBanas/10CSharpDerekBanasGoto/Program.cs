﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _10CSharpDerekBanasGoto
{
    class Program
    {
        static void Main(string[] args)
        {
            int age = 7;

          
            //The Swith has no range like python - short sighted by this 

            switch (age)
            {
                case 1:
                case 2: // 1or 2
                    Console.WriteLine("Go to day care");
                    break;

                case 3:
                case 4: // 1or 2
                    Console.WriteLine("Go to pre school");
                    break;

                case 5:

                    Console.WriteLine("Go to Kindergarden");
                    break;
                default:
                    Console.WriteLine("Go to another school");
                    goto OtherSchool;
            }
            //if this code is at the top it will be an unending loop till we change age
            OtherSchool:
            Console.WriteLine("Elementary, Middle, High School");
            
            Console.ReadLine();

        }
    }
}
