﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _07CSharpDerekBanasConditions_If_Else_
{
    class Program
    {
        static void Main(string[] args)
        {
            //Relational Operations : > < >= <= == !=
            //Logical Operations : && || !

            int age = 17;
            if ((age > 5) && (age <= 7))
            {
                Console.WriteLine("Go to elementary school");
            }
            else if ((age > 7) && (age < 13))
            {
                Console.WriteLine("Go to Middle school");
            }
            else if ((age > 13) && (age < 19))
            {
                Console.WriteLine("Go to High school");
            }
            else
            {
                Console.WriteLine("Go to College");
            }
            //OR
            if ((age < 14) || (age < 19))
            {
                Console.WriteLine("You Shouldn't work");

            }

            //Not(take true and turn it into false and wiseawesa
            Console.WriteLine("! true = "+ (!true));

            Console.ReadLine();
        }
    }
}
